# @rrg/ui-motion 0.3.1

Five small React motion patterns for existing RRG controls. The app owns state,
requests, accessible roles, permissions, routing, and announcements. This package
has no domain data, storage, networking, animation framework, or bundled React.

## Install a built archive

Copy the supplied archive into your project's `vendor/` directory, then run:

```sh
npm install ./vendor/rrg-ui-motion-0.3.1.tgz
```

The resulting dependency is `"@rrg/ui-motion": "file:vendor/rrg-ui-motion-0.3.1.tgz"`.
Commit the intended archive, manifest, and lockfile together when publication is
authorized. Import the CSS once before the app's integration styles:

```tsx
import '@rrg/ui-motion/styles.css'
import {
  SlidingTabs, TextStateSwap, AnimatedCheckbox, Accordion, AccordionTrigger, PanelReveal,
} from '@rrg/ui-motion'
```

The archive contains compiled ESM JavaScript, TypeScript declarations and CSS.
JS/JSX consumers use the same exports as TS/TSX consumers; no TypeScript compiler,
`prepare` script, private registry, or global CLI is needed to consume it.
Peer dependencies support React and React DOM 18.2 or 19; the Forge pilot verified
the installed React/React DOM 19.2.8 pair. Do not install another React copy.

## API

### SlidingTabs

`value: string` plus ordinary `div` props and a forwarded `HTMLDivElement` ref.
Mark each existing choice with `data-motion-tab` equal to its controlled value:

```tsx
<SlidingTabs value={mode} className="mode-switcher" role="group" aria-label="Tool">
  {modes.map(({ key, label }) => (
    <button key={key} data-motion-tab={key} aria-pressed={mode === key}
      onClick={() => setMode(key)}>{label}</button>
  ))}
</SlidingTabs>
```

Only the indicator moves (220 ms, position and width). Selection and content update
immediately. Initial placement and layout corrections snap. The indicator tracks
resize, changed labels/children, loaded fonts, visibility, and horizontal scrolling.
Keep the marked choice's own geometry stable; use the indicator for selected
background styling instead of changing the selected choice's padding.

The wrapper does not assign roles or keyboard handlers. Preserve normal buttons,
or real navigation links with `aria-current="page"`. Actual tabs must retain their
existing `role="tablist"`, `role="tab"`, roving tab index, arrow-key handling,
`aria-selected`, and `aria-controls`/`aria-labelledby` panel relationships.

Style `.rrg-motion-tabs__indicator` within the application's wrapper class, or use
`--rrg-motion-indicator-color` and `--rrg-motion-indicator-radius`. Choices are above
the decorative indicator; it has no pointer events or accessible content.

### TextStateSwap

`children: string`, optional `reserve?: readonly string[]`, ordinary `span` props,
and a forwarded `HTMLSpanElement` ref.

```tsx
<button onClick={copy} disabled={copying}>
  <TextStateSwap reserve={['Copy', 'Copying…', 'Copied', 'Copy failed']}>
    {actualCopyFeedback}
  </TextStateSwap>
</button>
```

The semantic and visible text are always the latest prop. Changes have a single
180 ms entrance (4 px maximum); there is no delayed exit, stale text, queued state,
or manufactured success. Initial text is static. New updates cancel the previous
animation. Hidden, `aria-hidden` pseudo-content reservations share the same grid
cell so declared alternatives reserve width and wrapping height without duplicate
text nodes or announcements. Choose short alternatives relevant to the control;
give the parent a real width constraint when source values must wrap in a table.

No live region is added. Preserve an existing surrounding status or supply
`role="status"`/`aria-live` only where the application already owns announcements.
Do not create a new live region on every row.

### AnimatedCheckbox

Native input props (optional `type` must be `'checkbox'`), `indeterminate?: boolean`,
`wrapperClassName?: string`, and a forwarded `HTMLInputElement` ref. `className`,
`style`, `id`, `name`, form props, change events, disabled state, and checked/default
checked values belong to the real input.

```tsx
<label>
  <AnimatedCheckbox checked={allSelected} indeterminate={someSelected && !allSelected}
    disabled={busy} onChange={(event) => selectAll(event.currentTarget.checked)} />
  Select visible rows
</label>
```

Only the decorative check stroke draws, once, in 150 ms. A mixed mark is static.
Unchecking and bulk values are immediate; restored checked values do not animate.
Omit `indeterminate` when an existing ref deliberately owns that native property.
The input remains keyboard-focusable, labelable, and part of native form behavior.
The wrapper adds no role, focus stop, or event handler. Forced-colors and print
use the platform's native checkbox appearance.

Input dimensions remain overridable by existing input classes. Match a custom
dimension using `--rrg-motion-checkbox-size` on the wrapper/ancestor (default 15px)
to size the decorative stroke. Other scoped variables: `--rrg-motion-accent`,
`--rrg-motion-checkbox-border`, `--rrg-motion-checkbox-background`,
`--rrg-motion-checkbox-mark`, and `--rrg-motion-focus`. Adapt old `input + label`
or `input + span` sibling selectors if they targeted the now-wrapped input.

### PanelReveal

`open: boolean`, `children`, optional `triggerRef?: RefObject<HTMLElement | null>`,
`immediate?: boolean`, `unmountOnExit?: boolean`, `animateOnMount?: boolean`,
`contentClassName?: string`, `contentStyle?: CSSProperties`, ordinary `div` props, and a
forwarded `HTMLDivElement` ref.

```tsx
const triggerRef = useRef<HTMLButtonElement>(null)
<button ref={triggerRef} aria-expanded={open} aria-controls="details"
  onClick={() => setOpen(!open)}>Details</button>
<PanelReveal id="details" open={open} triggerRef={triggerRef}>
  <ExistingDetails />
</PanelReveal>
```

Use this effect for an existing secondary surface such as a popover, dialog frame,
or newly created draft editor. Keep the surface's current role, focus management,
Escape/backdrop handling, and state ownership; no new disclosure step is required.
Do not apply Accordion and PanelReveal to the same opening body.

Opening is a restrained opacity fade from 0.65 to 1 in **180 ms**; closing fades
to 0 in **150 ms**. There is no translation, height/width keyframe or clipping.
The surface retains its natural, viewport-constrained size throughout. Existing
positioning transforms, max-height and scrolling remain app-owned, including in
reduced motion and print. Initial open content is static by default. Child edits
and validation immediately lay out naturally without restarting the fade. Rapid
toggles start from the current opacity and cancel stale completions.

**0.3.0 migration:** PanelReveal no longer animates occupied height. Use Accordion
for an inline disclosure whose following content should move smoothly. Keep
PanelReveal on popovers/dialogs and one-time new-editor entrances. A panel's outer
positioning surface can keep its width, padding, border, shadow and scroll limit;
place its options grid/flex layout on `contentClassName` rather than having both
outer and inner elements own the options layout. No positioning transform is
replaced by motion.

`animateOnMount` defaults to false. Opt in only when an existing user action mounts
a fresh surface, for example `result && <PanelReveal open animateOnMount={isManualPo}>`.
This reveals the new editor once; child edits and unrelated rerenders do not restart
it or remount its inputs. It works with React StrictMode effect replay. Do not opt
in for restored data or rerun the creation handler from an animation effect.

Closed content is immediately `aria-hidden` and inert; focus inside it returns to
the supplied trigger (or the focus target remembered when opening). Supply a
connected trigger where focus recovery matters. After exit it receives native
`hidden`; `data-motion-open` always represents the actual controlled prop, and
`data-motion-phase` reports `open`, `closed`, `opening`, or `closing`.

By default all children remain mounted while closed, retaining drafts. Set
`unmountOnExit` only when the original disclosure unmounted its children: initial
closed content then never mounts, and content unmounts after exit. Keep existing
app-owned draft state outside this wrapper as before. Set `immediate` when a lock
or permission loss removes protected content; a closed panel is hidden on that
render with no exit. Existing conditional security boundaries may remove the whole
component immediately instead. Never delay a security boundary for animation.

An immediate close hides and inerts the surface on the close render. Its
synchronous layout effect restores focus while the formerly focused child is
still attached, then removes `unmountOnExit` children before paint. Detaching
those children during the render itself would discard the evidence needed for
focus restoration. There is no security exit delay or visible retained frame.

For tables, render `tr > td > PanelReveal`, never put this `div` around a `tr`.
Use a spanning cell with existing table density rules. A retained structural row
can use a scoped `tr:has(.rrg-motion-panel[hidden]) { display: none; }` rule to remove
empty space once its reveal closes.

### Accordion and AccordionTrigger

`Accordion` accepts the same body props as PanelReveal and forwards an
`HTMLDivElement` ref. It moves **only actual occupied height** in normal page flow:
220 ms open, 160 ms closed. Following content moves with it; there is no extra
fade/translation or arbitrary max-height limit. A caller's existing pixel max-height
constraint is respected. Content resizing and responsive wrapping retarget an
opening within its original deadline; rapid reversals start from current visual
height. The natural inner body has `min-height: max-content` and cannot shrink as
the outer grid/flex envelope closes. Measurement includes its border box and
margins at the current available width; nested disclosures, validation and width
changes can retarget the envelope without measuring its own compression.
The body restores overflow after settling, hides/inerts closed content,
restores focus, and shares the same controlled mount/draft/security policy as
PanelReveal. Existing children are retained by default.

Keep an Accordion's outer element as the **height envelope**: width, positioning
and existing max-height/overflow limits may stay there. Put collapsible vertical
padding, borders, margins and options grid/flex layout inside it, using an existing
child wrapper or the new `contentClassName`/`contentStyle` props. An outer padded
border box cannot occupy zero height, so placing that spacing on the envelope
causes a residual strip and a jump when hidden. Do not override the inner body's
natural min-height or flex shrinking protection. For example:

```tsx
<Accordion open={open} className="options-envelope" contentClassName="options-grid">
  <ExistingOptions />
</Accordion>
// .options-envelope { max-height: 60vh; overflow: auto; }
// .options-grid { display: grid; gap: 8px; padding: 12px; border: 1px solid; }
```

`AccordionTrigger` accepts native button props plus required `open: boolean` and
`controls: string`, and forwards the native `HTMLButtonElement` ref. It always uses
`type="button"`, derives `aria-expanded` and `aria-controls` from those props, and
passes `onClick` directly to the native button. The application changes state.
Native Enter/Space activation, disabled behavior, labels, titles and focus remain
intact. It adds a small decorative turning chevron and no extra focus target.

```tsx
const [open, setOpen] = useState(true) // preserve the section's existing visibility
const triggerRef = useRef<HTMLButtonElement>(null)
<AccordionTrigger ref={triggerRef} open={open} controls="format-options"
  onClick={() => setOpen((current) => !current)}>Format options</AccordionTrigger>
<Accordion id="format-options" open={open} triggerRef={triggerRef}>
  <ExistingFormatOptions />
</Accordion>
```

Use Accordion for an existing inline contact/source detail, cleanup/settings group,
or equivalent disclosure. Preserve whether one or multiple sections can be open.
Keep required fields, primary actions, and unresolved warning summaries visible;
do not make ordinary actions or an entire workspace collapsible. Keep existing
native `details`/`summary` semantics when those are already used; the button helper
is optional and must not be nested inside another interactive trigger.

For a native `details` adapter, keep logical expanded state separate from the DOM
`open` attribute. The summary's existing click handler prevents its default toggle,
physically opens `details` **before** setting logical open, and gives that logical
state to Accordion. On logical close keep `details.open` true while the shared
body exits; observe the body's `hidden` attribute and physically close only after
it settles. The adapter must compare native `toggle` events and observer callbacks
against current state refs, because toggle events are queued/coalesced and may
describe an earlier transition. A programmatic retained open is not a new logical
open request. Do not add another animation or exit timer. Shared measurement waits
until a closed native ancestor becomes available; close/reopen and unmount cancel
that pending work. Preserve the actual summary, its keyboard activation, accurate
expanded/controls attributes and any existing initial-open/draft policy.

The root/inner classes are `.rrg-motion-accordion` and
`.rrg-motion-accordion__content`. State attributes and `[hidden]` match PanelReveal.
For a table use `tr > td > Accordion`; a scoped
`tr:has(.rrg-motion-accordion[hidden]) { display: none; }` can remove its empty row
after closing. The trigger class is `.rrg-motion-accordion-trigger`; style its
decorative `.rrg-motion-accordion-trigger__chevron` using
`--rrg-motion-chevron-size` (default `0.85em`) and `--rrg-motion-chevron-gap`
(default `0.35em`). The chevron uses the same open/close timing and easing, snaps on
initial mount, and responds immediately to reduced motion and print.

## Motion, accessibility and print

All five use `cubic-bezier(0.22, 1, 0.36, 1)` without bounce or blur. Reduced-motion
changes are subscribed to while mounted, cancel active animations, and introduce
no waits. CSS handles the same preference immediately. Printing resets only this
package's effects to actual final state, excludes closed panels, and does not touch
application print transforms, label scaling, rotations, pagination, or static marks.

The Web Animations API is used when available; absent support yields immediate
static text, checks, accordions, and panels. ResizeObserver improves live geometry tracking;
current evergreen browsers are the verification target. Server rendering is safe;
geometry and animation start after mounting in the browser.

## Canonical source and updates

Version 0.3.1 retains the 0.3.0 geometry correction and fixes immediate-close focus
restoration when `unmountOnExit` removes a focused input. Keep the initial 0.3.0
archive unchanged, but distribute 0.3.1 to consumers.

Version 0.3.0 repairs reveal geometry: PanelReveal is now a natural-size 180/150 ms
opacity effect; Accordion independently measures its natural inner layout at the
existing 220/160 ms timing. `contentClassName` and `contentStyle` make inner layout
ownership explicit. Existing exports, presence, draft and security props remain.
Version 0.2.0 introduced Accordion/AccordionTrigger and animateOnMount. Keep the
already handed-off 0.1.0 and 0.2.0 archives unchanged.

Canonical source lives in Forge's `packages/rrg-ui-motion/src/`. From the Forge root:

```sh
npm run build:motion
npm test
npm run typecheck:api
npm run build
npm run pack:motion
```

For a future version: change canonical source, run focused behavioral/browser
checks and required application checks, bump this package's version, build and pack
a **new versioned archive**, then update each consumer's file dependency and lockfile
to that artifact. Verify the installed archive's JS, declarations, CSS and build.
Never silently replace bytes of a version already handed to another project.
The Forge handoff document records the final path and SHA-256 for copying.

This is original RRG React/CSS code based on the requested behaviors. No
Transitions.dev source was copied, and no third-party source notices are required.
The referenced pages were unavailable during the first implementation.
